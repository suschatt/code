package Day1;

public class TableofTen {

	public static void main(String[] args) {
		for(int i=1;i<=20;i++){
			System.out.println("10 * "+i+"= "+10*i);
		}

	}

}
